import React, { useEffect, useRef } from 'react';
import ProjectCard from '../../components/ProjectCard';
import { motion, useAnimation } from 'framer-motion';

const Projects = () => {
    const projectData = [
        {id: 1, title: "Project 1", description: "Description of Project 1", techStack: ["Python", "TensorFlow"], github: "https://github.com/yourusername/project1", demo: "https://project1.com"},
        {id: 2, title: "Project 2", description: "Description of Project 2", techStack: ["R", "Shiny"], github: "https://github.com/yourusername/project2", demo: null}
    ];

    const projectRef = useRef(null);
    const controls = useAnimation();

    useEffect(() => {
        const observer = new IntersectionObserver(
            (entries) => {
                const entry = entries[0];
                if (entry.isIntersecting) {
                    controls.start('visible');
                } else {
                    controls.start('hidden');
                }
            },
            { threshold: 0.5 }
        );

        if (projectRef.current) {
            observer.observe(projectRef.current);
        }

        return () => {
            if (projectRef.current) {
                observer.unobserve(projectRef.current);
            }
        };
    }, [controls]);

    return (
        <motion.div 
            ref={projectRef} 
            animate={controls} 
            initial="hidden" 
            variants={{
                hidden: { opacity: 0 },
                visible: { opacity: 1, transition: { duration: 0.5, ease: "easeInOut" } }
            }}
        >
            <motion.h2 className="text-3xl font-bold mb-4">Projects</motion.h2>
            <motion.div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {projectData.map((project) => (
                    <ProjectCard key={project.id} project={project} />
                ))}
            </motion.div>
        </motion.div>
    );
};

// ✅ Ensure this default export is present
export default Projects;
