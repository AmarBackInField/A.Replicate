import React from 'react';
import Header from '../../components/Header';
import AboutMe from '../../components/AboutMe';
import Projects from '../Projects';
import Experience from '../../components/Experience';
import Skills from '../../components/Skills';
import ContactForm from '../../components/ContactForm';
import Footer from '../../components/Footer';
import { motion } from 'framer-motion';

const Home = () => (
  <motion.div
    initial={{ opacity: 0 }}
    animate={{ opacity: 1, transition: { duration: 0.75, ease: "easeInOut" } }}
    className='app'
  >
    <Header />
    <AboutMe />
    <Projects/>
    <Experience />
    <Skills />
    <ContactForm />
    <Footer />
  </motion.div>
);

export default Home;