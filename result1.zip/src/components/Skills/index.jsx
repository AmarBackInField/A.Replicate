import React from 'react';
import { motion, useAnimation } from 'framer-motion';
import { useEffect, useRef } from 'react';

const Skills = () => {
  const skillsRef = useRef(null);
  const controls = useAnimation();

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          controls.start('visible');
        }
      });
    });
    observer.observe(skillsRef.current);
    return () => observer.disconnect();
  }, [controls]);

  return (
    <motion.section
      ref={skillsRef}
      id="skills"
      className="p-4"
      animate={controls}
      initial="hidden"
      variants={{
        hidden: { opacity: 0 },
        visible: { opacity: 1, transition: { duration: 0.5, ease: "easeInOut" } },
      }}
    >
      <motion.h2
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0, transition: { duration: 0.5, delay: 0.2 } }}
        className="text-3xl font-bold mb-4"
      >
        Skills
      </motion.h2>
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1, transition: { duration: 0.5, delay: 0.4, staggerChildren: 0.1 } }}
        className="flex flex-wrap"
      >
        {["Python", "R", "SQL", "Tableau", "TensorFlow", "PyTorch", "Scikit-learn", "Pandas", "NumPy", "Git"].map((skill) => (
          <motion.span
            key={skill}
            className="bg-blue-100 text-blue-800 text-lg font-medium mr-2 mb-2 p-2 rounded"
            variants={{
              hidden: { opacity: 0, y: 20 },
              visible: { opacity: 1, y: 0 },
            }}
          >
            {skill}
          </motion.span>
        ))}
      </motion.div>
    </motion.section>
  );
};

export default Skills;