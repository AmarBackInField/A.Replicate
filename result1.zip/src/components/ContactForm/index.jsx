import React, { useState } from 'react';
import { motion } from 'framer-motion';

const ContactForm = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Implement form submission logic here (e.g., using fetch API)
    setSubmitted(true);
  };

  return (
    <motion.section
      initial={{ opacity: 0 }}
      animate={{ opacity: 1, transition: { duration: 0.5 } }}
      id="contact"
      className="p-4"
    >
      <motion.h2
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0, transition: { duration: 0.5, delay: 0.2 } }}
        className="text-3xl font-bold mb-4"
      >
        Contact
      </motion.h2>
      {submitted ? (
        <p>Thank you for your message!</p>
      ) : (
        <form onSubmit={handleSubmit}>
          <motion.input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Name"
            className="w-full mb-2 p-2 border border-gray-300 rounded"
            required
            whileFocus={{ scale: 1.02 }}
          />
          <motion.input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email"
            className="w-full mb-2 p-2 border border-gray-300 rounded"
            required
            whileFocus={{ scale: 1.02 }}
          />
          <motion.textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Message"
            className="w-full mb-2 p-2 border border-gray-300 rounded"
            required
            rows="5"
            whileFocus={{ scale: 1.02 }}
          />
          <motion.button
            type="submit"
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
            whileHover={{ scale: 1.02 }}
          >
            Submit
          </motion.button>
        </form>
      )}
    </motion.section>
  );
};

export default ContactForm;