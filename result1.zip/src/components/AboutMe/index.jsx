import React from 'react';
import { motion } from 'framer-motion';

const AboutMe = () => (
  <motion.section
    initial={{ opacity: 0 }}
    animate={{ opacity: 1, transition: { duration: 0.5 } }}
    id="about"
    className="p-4"
  >
    <motion.h2
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0, transition: { duration: 0.5, delay: 0.2 } }}
      className="text-3xl font-bold mb-4"
    >
      About Me
    </motion.h2>
    <div className="flex">
      <motion.img
        initial={{ opacity: 0 }}
        animate={{ opacity: 1, transition: { duration: 0.5, delay: 0.4 } }}
        src="/images/profile.jpg"
        alt="Amar Choudhary"
        className="w-48 h-48 rounded-full mr-4"
      />
      <motion.p
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0, transition: { duration: 0.5, delay: 0.6 } }}
        className="text-lg text-gray-700"
      >
        I am Amar Choudhary, a highly motivated and results-oriented Data Scientist with 3 years of experience in AI and ML. 
        I am passionate about leveraging data to solve complex business problems. My skills include ...
      </motion.p>
    </div>
  </motion.section>
);

export default AboutMe;