import React from 'react';
import { motion } from 'framer-motion';

const ProjectCard = ({ project }) => (
  <motion.div
    variants={{
      hidden: { scale: 0.8, opacity: 0 },
      visible: { scale: 1, opacity: 1, transition: { duration: 0.5 } },
    }}
    initial="hidden"
    animate="visible"
    whileHover={{ scale: 1.05 }}
    className="bg-white shadow-md rounded-lg p-4 m-4"
  >
    <motion.h2 className="text-xl font-bold mb-2">{project.title}</motion.h2>
    <motion.p className="text-gray-700 mb-2">{project.description}</motion.p>
    <div className="mb-2">
      <span className="text-gray-600 font-mono">Tech Stack: </span>{project.techStack.map((tech) => (
        <span key={tech} className="bg-gray-200 p-1 rounded-md mr-1">{tech}</span>
      ))}
    </div>
    <div className="flex space-x-2">
      <a href={project.github} target="_blank" rel="noopener noreferrer" className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
        GitHub
      </a>
      {project.demo && (
        <a href={project.demo} target="_blank" rel="noopener noreferrer" className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
          Demo
        </a>
      )}
    </div>
  </motion.div>
);

export default ProjectCard;