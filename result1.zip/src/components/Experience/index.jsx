import React from 'react';
import { motion } from 'framer-motion';

const Experience = () => (
  <motion.section
    initial={{ opacity: 0 }}
    animate={{ opacity: 1, transition: { duration: 0.5 } }}
    id="experience"
    className="p-4"
  >
    <motion.h2
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0, transition: { duration: 0.5, delay: 0.2 } }}
      className="text-3xl font-bold mb-4"
    >
      Experience
    </motion.h2>
    <div className="timeline">
      {/* Add experience entries here using appropriate components */}
    </div>
  </motion.section>
);

export default Experience;